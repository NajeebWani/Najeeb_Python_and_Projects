# Customer Segmentation (K-Means)

Grouping mall customers into segments based on annual income and spending
score, so you could target different groups with different marketing
strategies (e.g. don't waste ad budget on people who have money but don't
spend it here).

## Dataset

`data/mall_customers.csv` - 200 customers with gender, age, annual income
(in $k), and a spending score from 1-100. I generated this myself
(`generate_data.py`) in the same style as the well-known Kaggle "Mall
Customer Segmentation" dataset, since I wanted something with realistic
looking clusters to work with.

## Approach

1. Scaled `AnnualIncome` and `SpendingScore` with StandardScaler - important
   for K-Means since it's distance based and income/spending are on very
   different scales.
2. Used the elbow method to figure out a good number of clusters (k) - see
   `images/elbow.png`, the "elbow" is pretty clearly around k=5.
3. Ran K-Means with k=5 and plotted the result.
4. Pulled a summary table (average age/income/spending per cluster) to
   actually describe what each group looks like.

## What the clusters look like

Roughly 5 groups fall out of this:
- High income, high spending - the most valuable customers
- High income, low spending - money but not spending it here, worth
  investigating why
- Mid income, mid spending - the "average" customer
- Low income, high spending - spends a lot relative to what they earn
- Low income, low spending

(exact cluster numbers can shift between runs since KMeans initialization
isn't fixed order - always check the summary table it prints instead of
assuming cluster 0 = group X)

## Files

- `generate_data.py` - creates the sample dataset
- `segmentation.py` - scaling, elbow method, clustering, and cluster summary
- `images/elbow.png`, `images/clusters.png`

## Running it

```
pip install pandas numpy matplotlib seaborn scikit-learn
python generate_data.py
python segmentation.py
```

## Next steps

- Swap in a real dataset (Kaggle's Mall Customer Segmentation Data is the
  classic one) if you want real-world validation
- Try adding `Age` as a third clustering dimension
- Compare against DBSCAN or hierarchical clustering
