"""
Just making up a small "mall customers" style dataset since I don't have
a real one handy. Columns: customer id, gender, age, annual income (k$),
spending score (1-100). This is the same shape as the popular Kaggle mall
customers dataset, just generated so the numbers make sense.
"""

import numpy as np
import pandas as pd

rng = np.random.default_rng(7)
n = 200

# build a few natural-ish clusters of customers rather than pure random noise
segments = [
    {"n": 45, "income": (20, 6), "spend": (20, 8)},    # low income, low spend
    {"n": 40, "income": (25, 5), "spend": (78, 8)},    # low income, high spend (impulsive?)
    {"n": 45, "income": (60, 8), "spend": (50, 12)},   # mid income, mid spend
    {"n": 35, "income": (85, 8), "spend": (18, 8)},    # high income, low spend (careful spenders)
    {"n": 35, "income": (90, 8), "spend": (85, 8)},    # high income, high spend
]

rows = []
cid = 1
for seg in segments:
    incomes = rng.normal(seg["income"][0], seg["income"][1], seg["n"])
    spends = rng.normal(seg["spend"][0], seg["spend"][1], seg["n"])
    ages = rng.integers(18, 70, seg["n"])
    genders = rng.choice(["Male", "Female"], seg["n"])
    for i in range(seg["n"]):
        rows.append({
            "CustomerID": cid,
            "Gender": genders[i],
            "Age": int(ages[i]),
            "AnnualIncome": round(max(incomes[i], 5), 1),
            "SpendingScore": int(np.clip(spends[i], 1, 100)),
        })
        cid += 1

df = pd.DataFrame(rows).sample(frac=1, random_state=1).reset_index(drop=True)
df["CustomerID"] = range(1, len(df) + 1)
df.to_csv("data/mall_customers.csv", index=False)
print("saved", df.shape, "rows to data/mall_customers.csv")
