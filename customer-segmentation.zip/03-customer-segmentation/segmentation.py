"""
Customer Segmentation with K-Means

Grouping mall customers by income and spending behaviour so a marketing
team could target each group differently.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df = pd.read_csv("data/mall_customers.csv")
print(df.head())
print(df.describe())

X = df[["AnnualIncome", "SpendingScore"]]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# elbow method to pick k
inertias = []
k_range = range(1, 10)
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertias.append(km.inertia_)

plt.figure(figsize=(6, 4))
plt.plot(list(k_range), inertias, marker="o")
plt.xlabel("k")
plt.ylabel("Inertia")
plt.title("Elbow method")
plt.tight_layout()
plt.savefig("images/elbow.png", dpi=120)
plt.close()

# elbow points to 5 clusters for this data
k = 5
km = KMeans(n_clusters=k, random_state=42, n_init=10)
df["cluster"] = km.fit_predict(X_scaled)

plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x="AnnualIncome", y="SpendingScore", hue="cluster", palette="tab10", s=60)
plt.title("Customer segments (k=5)")
plt.tight_layout()
plt.savefig("images/clusters.png", dpi=120)
plt.close()

# quick summary of each group, this is the useful bit for a marketing team
summary = df.groupby("cluster")[["Age", "AnnualIncome", "SpendingScore"]].mean().round(1)
summary["count"] = df["cluster"].value_counts()
print("\nCluster summary:")
print(summary)

labels = {
    0: "Careful shoppers - decent income, spend little",
    1: "Budget high-spenders - low income but high spending score",
    2: "Average joe - mid income, mid spending",
    3: "High value - high income and high spending, target these first",
    4: "Low income, low spending",
}
# note: the actual label->cluster mapping depends on how KMeans assigns
# cluster ids, so check the printed summary before trusting these labels
print("\n(labels are approximate, match them up against the summary table above)")
for k_, v in labels.items():
    print(k_, "-", v)

df.to_csv("data/mall_customers_clustered.csv", index=False)
print("\nsaved clustered data")
