"""
Diamond Price Prediction

Given a diamond's carat, cut, color, clarity and dimensions, predict its
price. Regression problem, using the seaborn diamonds dataset (~54k rows).
"""

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

df = sns.load_dataset("diamonds")
print(df.shape)
print(df.describe())

# sample it down, 54k rows is more than we need for a quick project and it
# makes the random forest painfully slow otherwise
df = df.sample(n=12000, random_state=1).reset_index(drop=True)

# a few weird rows have 0 for dimensions, get rid of those
df = df[(df.x > 0) & (df.y > 0) & (df.z > 0)]

plt.figure(figsize=(6, 4))
sns.scatterplot(data=df.sample(2000, random_state=1), x="carat", y="price", hue="cut", alpha=0.5)
plt.title("Price vs Carat")
plt.tight_layout()
plt.savefig("images/price_vs_carat.png", dpi=120)
plt.close()

cat_cols = ["cut", "color", "clarity"]
cut_order = [["Fair", "Good", "Very Good", "Premium", "Ideal"]]
color_order = [["J", "I", "H", "G", "F", "E", "D"]]
clarity_order = [["I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"]]

enc_cut = OrdinalEncoder(categories=cut_order)
enc_color = OrdinalEncoder(categories=color_order)
enc_clarity = OrdinalEncoder(categories=clarity_order)

df["cut_enc"] = enc_cut.fit_transform(df[["cut"]])
df["color_enc"] = enc_color.fit_transform(df[["color"]])
df["clarity_enc"] = enc_clarity.fit_transform(df[["clarity"]])

features = ["carat", "cut_enc", "color_enc", "clarity_enc", "depth", "table", "x", "y", "z"]
X = df[features]
y = df["price"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)

lr = LinearRegression()
lr.fit(X_train, y_train)
lr_pred = lr.predict(X_test)

rf = RandomForestRegressor(n_estimators=150, max_depth=12, random_state=1, n_jobs=-1)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)

def report(name, y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    print(f"{name}: MAE=${mae:,.0f}  R2={r2:.3f}")

report("Linear Regression", y_test, lr_pred)
report("Random Forest", y_test, rf_pred)

# plot predicted vs actual for the forest model
plt.figure(figsize=(5, 5))
plt.scatter(y_test, rf_pred, alpha=0.3, s=10)
plt.plot([0, y_test.max()], [0, y_test.max()], color="red", linestyle="--")
plt.xlabel("Actual price")
plt.ylabel("Predicted price")
plt.title("Random Forest: predicted vs actual")
plt.tight_layout()
plt.savefig("images/predicted_vs_actual.png", dpi=120)
plt.close()

importances = pd.Series(rf.feature_importances_, index=features).sort_values()
plt.figure(figsize=(6, 4))
importances.plot(kind="barh")
plt.title("Feature importance")
plt.tight_layout()
plt.savefig("images/feature_importance.png", dpi=120)
plt.close()

print("done")
