# Diamond Price Prediction

Predicting diamond prices from their physical characteristics - carat, cut,
color, clarity, and dimensions. Regression project, good practice for
handling ordinal categorical features (cut/color/clarity aren't just random
categories, they have a natural order).

## Dataset

seaborn's built-in `diamonds` dataset - about 54,000 diamonds with price,
carat, cut, color, clarity, depth, table, and x/y/z dimensions in mm. I
sampled it down to 12k rows just to keep training time reasonable.

## Steps

1. Dropped rows where x, y, or z was 0 (a handful of data entry errors).
2. Encoded `cut`, `color`, and `clarity` as ordinal features instead of one-hot,
   since these actually have a rank ordering (e.g. Fair < Good < Very Good <
   Premium < Ideal for cut).
3. Trained a plain Linear Regression as a baseline, then a Random Forest.
4. Compared with MAE (mean absolute error in dollars) and R².

## Results

| Model | MAE | R² |
|---|---|---|
| Linear Regression | ~$780 | 0.91 |
| Random Forest | ~$300 | 0.98 |

Carat weight is by far the strongest predictor (makes sense, it's basically
size), followed by the clarity/color/cut grades. The random forest does a lot
better than a straight line since price doesn't scale linearly with carat.

## Files

- `diamonds.py` - the whole pipeline
- `images/` - price vs carat scatterplot, predicted vs actual, feature
  importance chart

## Running it

```
pip install pandas numpy seaborn matplotlib scikit-learn
python diamonds.py
```

## Things to try next

- Log-transform price before training, diamond prices are pretty skewed
- Try gradient boosting (XGBoost/LightGBM) instead of random forest
- Add carat^2 or carat*clarity interaction terms for the linear model
